////////// TestUtilityLoader.proto //////////
test {{loader}} prototype

////////// TestUtilityLoader //////////
//@requires: OtherUtility
test {{loader}} impl

////////// OtherUtility.proto //////////
req {{loader}} proto

////////// OtherUtility //////////
req {{loader}} impl
